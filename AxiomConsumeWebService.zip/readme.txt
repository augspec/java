﻿************************************************************************
***                       TÍCH HỢP VÀ SỬ DỤNG                        ***
************************************************************************
- Thêm AxiomConsumeWS.jar vào Build Paht.
- Copy file axiom-config.properties vào Sources Folder (thư mục src) của
Project Java và điều chỉnh các thông số cấu hình với mục đích sử dụng, -
do các giá trị là fix cứng nên khi triển khai chạy một ứng dụng web hay-
thì các đường dẫn mà file cấu hình bắt buộc ta có thể lấy cố định trên -
server.

- Thêm tất cả file jars trong thư mục lib vào class-path (eclipse thì t-
hêm vào Build Path) của project.

- Thư mục axiom (repository hay dịch thô ra tiếng việt thì là kho chứa)-
có chứa các modules và file cấu hình của axis2 (các cấu hình tùy chỉnh -
trong file axis2.xml), nên copy hoặc di chuyển 2 file axiom/conf/commons
-logging.properties và axiom/conf/log4j vào Sources Folder (thư mục src)
của Project, nơi mà đã đặt file axiom-config.properties (đã nói phía tr-
ên).

* Lưu ý: nên copy thư mục axiom vào thư mục gốc của project sau đó lấy -
đường dẫn tuyệt đối của thư mục này đặt vào repository và đường dẫn file
axis2.xml trong file axiom-config.properties (đã có chú thích tiếng anh-
và điền giá trị mẫu, có thể tham khảo).

- Để sử dụng thì rất đơn giản, cần tìm hiểu qua cấu trúc tài liệu WSDL -
để gọi hàm thì sử dụng class AxiomUtil.callService(String enpointUri, S-
tring soapAction, String targetNamspace, String method, Map<String, Obj-
ect> paramsAndValuesMap) trong đó:
    + enpointUri: URL của tài liệu WSDL (tức là link web service).
    + soapAction: là action cần gọi, tìm trong tài liệu WSDL sẽ có.
    + targetNamspace: trong tài liệu WSDL có 1 thuộc tính này ở thẻ gốc-
      ta sẽ lấy ở đó.
    + method: tên hàm cần gọi.
    + paramsAndValuesMap: là danh sách tên tham số và giá trị tương ứng-
      tùy thuộc vào action gọi có tham số hay không, nếu không có tham -
      số nào (hàm void) thì truyền null hoặc Map rỗng.

Ví dụ:
    - enpointUri: https://example.com/service/Calculator?wsdl
    - soapAction: https://example.com/service/Calculator/Add
    - method: Add
    - targetNamespace: https://tempuri.org/
    - paramsAndValue: hàm Add có 2 tham số (Add(num1, num2))
        + Tham số 1: tên: num1, giá trị: 5
        + Tham số 2: tên: num2, giá trị: 65
    Gọi hàm như sau:
        Map<String, Object> params = new HashMap<String, Object>();
        params.put("num1", 5);
        params.put("num2", 65);
        OMElement result = AxiomUtil.callService("https://example.com/se
        -rvice/Calculator?wsdl", "https://example.com/service/Calculator
        -/Add", "https://tempuri.org/", "Add", params);

    - soapAction: https://example.com/service/Calculator/GetDateTimeNow
    - method: GetDateTimeNow
    - paramsAndValue: không có tham số, truyền null
    Gọi hàm như sau:
        OMElement result = AxiomUtil.callService("https://example.com/se
        -rvice/Calculator?wsdl", "https://example.com/service/Calculator
        -/GetDateTimeNow","https://tempuri.org/","GetDateTimeNow",null);

Phân tích result (OMElement), bóc XML để xử lý dữ liệu tùy theo yêu cầu.